const elements_id = document.querySelectorAll('[id]') // Cria uma lista que contêm todos os id

