const container_bio = document.getElementById("container-bio");
const botoes = document.querySelectorAll(".selector-personagem");

botoes.forEach(botao => {
    botao.addEventListener("click", () => {
        const personagemId = botao.dataset.id;

        fetch(`/biografia/${personagemId}`)
            .then(response => {
                if (!response.ok) {
                    // This will be caught by the final .catch() block
                    throw new Error('A resposta da rede não foi bem-sucedida.');
                }
                // Return the promise from response.json()
                return response.json(); 
            })
            .then(data => {
                // This block runs only if the promise chain is successful
                container_bio.innerHTML = `
                    <h2>${data.nome}</h2>
                    <p>${data.texto}</p>
                `;
            })
            .catch(error => {
                // This single catch block handles all errors from the entire chain
                console.error('Erro na requisição:', error); // Good for debugging
                container_bio.innerHTML = `<h2>Ocorreu um erro</h2><p>Não foi possível carregar os dados. Detalhe: ${error.message}</p>`;
            });
    });
});