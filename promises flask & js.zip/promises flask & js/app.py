from flask import Flask, render_template, redirect, request, jsonify

app = Flask(__name__)

dados_biografia = {
    "Santos Dumont": {
        "nome": "Santos Dumont",
        "texto": "fkwjefwjfpwkejfpwjgwgj",
    },

    "Elon Musk": {
        "nome": "Elon Musk",
        "texto": "fkwjefwjfpwkejfpwjgwgj",
    },

    "Bil Gates": {
        "nome": "Bil Gates",
        "texto": "fkwjefwjfpwkejfpwjgwgj",
    }
}


@app.route('/')
def index():
    personagens = dados_biografia.keys()
    return render_template('index.html', personagens=personagens, nomes=dados_biografia)

@app.route('/biografia/<id_personagem>')
def get_biografia(id_personagem):
     # .get retorna o valor da chave passada no 1 param, caso a chave não exista o 2 param é o valor que sera atribuido caso a chave nao exista (O padrão é None)
    biografia_data = dados_biografia.get(id_personagem, { 
        "nome": "desconhecido",
        "texto": "personagem não encontrado"
    })

    return jsonify(biografia_data)


if __name__ == '__main__':
    app.run(debug=True)