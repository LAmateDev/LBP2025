let cont = 1;
let timer;

document.getElementById("radio1").checked = true;

// Função para trocar para a próxima imagem
function nextImage() {
    cont++;
    if (cont > 6) cont = 1;
    document.getElementById("radio" + cont).checked = true;
    startTimer(); // reinicia o timer
}

// Inicia o timer (usando setTimeout)
function startTimer() {
    clearTimeout(timer); // limpa o timer atual, se houver
    timer = setTimeout(nextImage, 5000); // define novo timer
}

// Atualiza o contador se usuário clicar em uma imagem
function atualizarCont(n) {
    cont = n;
    startTimer(); // reinicia o timer ao clicar
}

// Início automático
startTimer();
