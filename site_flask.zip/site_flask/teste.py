import json

with open("usuarios.json", "r") as arquivo:
    usuarios = json.load(arquivo)

print(usuarios)

