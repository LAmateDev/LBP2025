users = {'eduardo': '34234', 'maria': '12345'}

for user in users:
    print(users.keys())
