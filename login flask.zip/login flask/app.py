from flask import Flask, render_template, session, redirect, url_for, request
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

logins = {'Carlos': 'ab1234c', 'Thiago': '123acb', 'Lucas': 'abc001'
}

@app.route('/home')

def home():
    return render_template("home.html", nome = session["nome"])

@app.route('/login',  methods=['GET', 'POST'])

def login():
    logado = False
    mensagem = ""

    if request.method == 'POST':
        session["nome"] = request.form.get("usuario")
        senha = request.form.get("senha")
    
        # loop que itera sobre o dicionario de logins
        for user in logins:
            if session["nome"] == user and senha == logins[user]:
                logado = True
                return redirect(url_for("home"))
            
        mensagem = "Usuário ou senha inválidos"
        return render_template('login.html', logado = logado, mensagem = mensagem)
    else:
        return render_template('login.html')
    

if __name__ == "__main__":
    app.run(debug=True)