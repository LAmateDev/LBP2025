from flask import Flask, render_template, request, url_for, redirect, session
from model import UsuarioModel

app = Flask(__name__)
app.config["SECRET_KEY"] = "chavesecreta"

usuario_model = UsuarioModel()

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/add_usuario", methods=["POST"])
def adicionar_usuario():
    nome = request.form.get("nome")
    email = request.form.get("email")
    usuario_model.save_user(nome, email)
    
    return render_template("login.html")

@app.route("/usuarios")
def listar_usuaruios():
    lista_usuarios = usuario_model.get_all()
    return render_template("usuarios.html", usuarios=lista_usuarios)


@app.route("/login", methods=["POST"])
def login():
    nome = request.form.get("nome")
    senha = request.form.get("senha")

    usuarios = usuario_model.get_all()

    for id in usuarios:
        if usuarios[id]["nome"] == nome and usuarios[id]["senha"] == senha:
            session["logado"] = True
            session["adm"] = usuarios[id]["adm"]
            return redirect(url_for("home"))
    
    mensagem = "Usuario ou senha inválidos!"
    return render_template("login.html", mensagem=mensagem)

@app.route("/delete", methods=["POST"])
def delete():
    id = request.form.get("id")
    if usuario_model.delete_usuario(id):
        mensagem = "suario deletado com sucesso!"
        return render_template("delete.html", mensagem=mensagem)
    else:
        mensagem = "O id do usuario não existe"
        return render_template("delete.html", mensagem=mensagem)


    

if __name__ == "__main__":
    app.run(debug=True)