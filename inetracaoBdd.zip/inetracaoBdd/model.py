class UsuarioModel:
    _usuarios = {1: {"nome": "qualquer nome", "email": "qualquecoisas@gmail.com","senha": "adm123","adm": True},
                 2: {"nome": "shwohwlkehg", "email": "dghasdb@email.com","senha": "teste123", "adm": False}}

    _next_id = 3
    
    def get_user(self, id):
        return self._usuarios[id] 
    
    def get_all(self):
        return self._usuarios
    
    def save_user(self, nome, email):
        self._usuarios[self._next_id] = {"nome": nome, "email": email}
        self._next_id += 1

    def delete_usuario(self, id):
        if id in self._usuarios:
            self._usuarios.pop(id)
            return True
        else:
            return False
